﻿本程序是Paxos是压力测试代码
其中Paxos文件夹下面是paxos算法封装代码
lib文件加下是Paxos.cpp依赖代码
Paxos文件夹下的代码，并不依赖任何代码
