package gorocksdb

// #cgo LDFLAGS: -lrocksdb -lstdc++ -lm
import "C"
