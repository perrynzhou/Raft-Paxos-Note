> Note: for reported bugs, please fill in the following details. bug reports without detailed steps on how to reproduce will be automatically closed. 

### Dragonboat version

### Expected behavior

### Actual behavior

### Steps to reproduce the behavior
